package com.CodingDojo.GettingFamiliar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GettingFamiliarApplication {

	public static void main(String[] args) {
		SpringApplication.run(GettingFamiliarApplication.class, args);
	}
}
