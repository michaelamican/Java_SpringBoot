package com.CodingDojo.Classy.config;

public class WebSecurityConfig {

}
