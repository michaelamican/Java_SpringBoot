/**
 * 
 */
function alertDate(){
	alert("This is the date template");
}
alertDate();